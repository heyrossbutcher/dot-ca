<?php

/*
	Template Name: Custom Home Page
*/

get_header();  ?>


<div class="mobile_header hide">
	<img src="<?php bloginfo( 'template_url' ); ?>/img/title.jpg" alt="">
</div>

<div class="mobile_contact hide">
	<div class="open">
		<i class="fa fa-bars"></i> Contact
	</div>
	<div class="mobile_contact_items hide">
			<div class="mobile_contact_item">
				<a href="tel:6476686850">(647) 668-6850</a>
			</div>	
			<div class="mobile_contact_item">
				<a href="mailto:heyross@rossbutcher.ca?subject=Hey ">Email</a>
			</div>	
		<!--  -->
		<?php $latestPosts = new wp_query(array(
			'post_type' => 'social',//we only want social pieces
			'posts_per_page' => -1
		)) ?>
		<!--  -->

		<?php if($latestPosts->have_posts()) while($latestPosts->have_posts()) : $latestPosts->the_post() ?>
			<div class="mobile_contact_item">
				<a href="<?php the_field('link_to');  //put the link ?>" target="blank">
					<?php the_field('which_social');  //Assign the class ?>
				</a>
			</div>
		<?php endwhile; ?><!-- //end custom loop -->

		</div>


	</div>
</div>

<div class="vid_holder">
	<video autoplay loop poster="<?php bloginfo( 'template_url' ); ?>/img/intro.jpg" id="bgvidin">
	  <source src="<?php bloginfo( 'template_url' ); ?>/img/intro.mp4" type="video/mp4">
	</video>	
</div>
<div class="img_holder hide" style="background-image: url(<?php bloginfo( 'template_url' ); ?>/img/intro.jpg)">
	
</div>
<div class="main">
	<div class="key_instruct remove clearfix">

		<svg version="1.1" id="arrow" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			 viewBox="0 0 274.3 178.2" enable-background="new 0 0 274.3 178.2" xml:space="preserve">

			<g class="keys">

				<path fill="rgba(255,255,255,0)" stroke-miterlimit="10" d="M168.3,85.4h-61.6c-6.6,0-12-5.4-12-12V13.2c0-6.6,5.4-12,12-12
					h61.6c6.6,0,12,5.4,12,12v60.2C180.3,80,174.9,85.4,168.3,85.4z"/>

					<polygon points="129.8,31.8 123.1,17.6 116,31.8 121.5,31.8 121.5,52.1 124.7,52.1 124.7,31.8 "/>

				<g class="arrow_highlight">
					<path stroke-miterlimit="10" d="M168.3,177h-61.6c-6.6,0-12-5.4-12-12v-60.2c0-6.6,5.4-12,12-12
						h61.6c6.6,0,12,5.4,12,12V165C180.3,171.6,174.9,177,168.3,177z"/>
				</g>

				<g class="direct_arrows">
					<polygon points="116,133.8 122.7,148 129.8,133.8 124.3,133.8 124.3,113.5 121.2,113.5 121.2,133.8 "/>
				</g>
				<path fill="none" stroke-miterlimit="10" d="M260.4,177h-61.6c-6.6,0-12-5.4-12-12v-60.2c0-6.6,5.4-12,12-12h61.6
					c6.6,0,12,5.4,12,12V165C272.4,171.6,267,177,260.4,177z"/>
				<polygon points="232.6,137.6 246.8,130.9 232.6,123.8 232.6,129.3 212.3,129.3 212.3,132.5 232.6,132.5 "/>
				<path fill="none" stroke-miterlimit="10" d="M75.5,177H13.9c-6.6,0-12-5.4-12-12v-60.2c0-6.6,5.4-12,12-12h61.6
					c6.6,0,12,5.4,12,12V165C87.5,171.6,82.1,177,75.5,177z"/>
				<polygon points="41.7,123.8 27.4,130.5 41.7,137.6 41.7,132.1 61.9,132.1 61.9,129 41.7,129 "/>
			</g>

		</svg>
		
		<div class="key_cta">
			Press the arrow on the keyboard to begin
		</div>

	</div><!-- End of Key Instruct -->


	<div class="aftereights remove clearfix">
		
		<div class="thanks_cta">
			Thanks for visiting.
		</div>

	</div> <!-- End of After Eights --> 
	<div class="mobile_instruct hide">
		Scroll to see the work
	</div>
	<div class="circle hide">
		<i class="fa fa-arrow-down"></i>
	</div>

  <div class="container clearfix">
		

	<?php //we are going to pull in the latest portfolio pieces ?>
	<?php $latestPosts = new wp_query(array(
		'post_type' => 'portfolio',//we only want portfolio pieces
		'posts_per_page' => -1
	)) ?>
			
	<?php if($latestPosts->have_posts()) while($latestPosts->have_posts()) : $latestPosts->the_post() ?>
	
	<?php //LOAD IN THE PORTFOLIO PIECES ?>
		<?php $image = get_field('screenshot');  //Get the image for processing ?>

		<div class="select-holder clearfix piece<?php the_field('nav_select');  ?>" style="background-image: url(<?php echo $image['sizes']['portfolio']; //Print the screenshot?>)">

            <?php //pre_r($post); ?>
		    
		    <?php $postid = get_the_ID(); //Get the portfolio piece id?>
				<!-- <div class="title hide clearfix"> -->
				<div class="wrap clearfix">

					<div class="excerpt clearfix">

						<h3><a href="<?php the_field('link'); ?>" target="-"><?php the_field('project_title');  //Project title ?></a></h3>

						<div class="e_text">
							<p><?php the_field('excerpt_description');  //Get the image ?></p>
						</div>
							
						<div class="tech_list">

							<div class="tech_item used">
								<?php 
									if( $postid == '31'):
										echo 'Skills include';
									else:
										echo 'Built in';
									endif;
								?>
							</div>
								
			                    <?php $taxonomyItems = get_the_terms($post->ID, 'technologies');
			                    // pre_r($taxonomyItems[4][1]);			
			                    foreach ($taxonomyItems as $taxonomyItem) {
			                      echo '<div class="tech_item '.$taxonomyItem->name.'">'.$taxonomyItem->name.'</div>';
			                    }; ?>
						</div>
						
						<?php if($postid !== 31) : ?>

		                	<div class="try_it_out">
		                		<a href="<?php the_field('link'); ?>" target="_">
		                			<span class='link_swap'>View it live  <i class="fa fa-chevron-right"></i></span>
		                		</a>
	                		</div>
	                		<div class="mobile_try_it_out hide">
		                		<a href="<?php the_field('link'); ?>" target="_">
		                			View it live  <i class="fa fa-chevron-right"></i>
		                		</a>
	                		</div>

	                	<?php endif; ?>
						




					</div><!-- End of excerpt -->

				</div><!-- End of wrap -->

		</div><!-- End of Select Holder -->

	<?php endwhile; ?><!-- //end custom loop -->

		<div class="portfolios-nav">
			<?php if($latestPosts->have_posts()) while($latestPosts->have_posts()) : $latestPosts->the_post() ?>
				<?php //LOAD IN THE PORTFOLIO NAV CIRCLES ?>
				<div class="portfolio-nav nav<?php the_field('nav_select');  //Project title ?> ">
					 <?php //the_field('nav_select');  //Project title ?> 
				</div>

			     <?php //the_terms($post->ID,'technologies'); ?>
			<?php endwhile; ?><!-- //end custom loop -->
		</div>
	<?php wp_reset_postdata(); ?><!-- //return to regular formatiing -->


  </div> <!-- /.container -->
</div> <!-- /.main -->

<?php get_footer(); ?>